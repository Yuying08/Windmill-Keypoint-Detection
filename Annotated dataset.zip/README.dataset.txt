# windmill_root > 2024-07-17 5:48pm
https://universe.roboflow.com/technische-universitt-berlin-o3p5k/windmill_root

Provided by a Roboflow user
License: CC BY 4.0

